import { Token } from "@roimaswap/sdk";
import { useEffect, useState } from "react";

export default function useMarketData() {
    const [marketData, setMarketData] = useState();

    useEffect(() => {
    }, []);
    
}