export function pairKey(token0Address: string, token1Address: string) {
  return `${token0Address};${token1Address}`;
}
