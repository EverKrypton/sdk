export default function getBackendURL() {
  const { hostname } = window.location;

  let baseURL = 'https://apidev.RoimaSwap.com';
  if (hostname === 'RoimaSwap.com') {
    baseURL = 'https://api.RoimaSwap.com';
  } else if (hostname.indexOf('localhost') > -1) {
    baseURL = 'http://localhost';
  }
  return baseURL;
}
