import React from "react";

export const VerticalGridLine = (props: { left: number }) => (
  <div className="VerticalGridLine" style={{ left: props.left }}></div>
);
